
function myFunction() {
 document.body.style.backgroundImage = "url('http://www.bosontreinamentos.com.br/wp-content/uploads/2018/03/codar-aprender-programação-e1526220792410.jpeg')";
}
function myFunction1() {
   document.body.style.backgroundImage = "url('https://cdn.pixabay.com/photo/2014/12/30/10/39/code-583795_960_720.jpg')";
   
}
setInterval(myFunction, 300);
setInterval(myFunction1, 600);

function validarIdade(){
var idade = document.getElementById("idade");
var nome = document.getElementById("nome");
var telefone = document.getElementById("telefone");
var email = document.getElementById("email");
var sexo = document.getElementById("sexo");
var data = document.getElementById("data");

  
  if(nome.value == ""){
   
    alert("insira seu nome");
    document.getElementById("nome").style.borderColor = "#ff0000";


  }
  if(telefone.value == ""){
   
    alert("insira seu telefone");
    document.getElementById("telefone").style.borderColor = "#ff0000";
  }
  if(email.value == ""){
   
    alert("insira seu email");
    document.getElementById("email").style.borderColor = "#ff0000";


  }
  
 if(idade.value == ""){
   
    alert("insira sua idade");
    document.getElementById("idade").style.borderColor = "#ff0000";


}else{
  if(idade.value >= 18){
    alert("vc pode tira CHN");

  }else{
    alert("vc nao pode tirar CNH");
  }
}
if(data.value == ""){
   
    alert("insira a data");
    document.getElementById("data").style.borderColor = "#ff0000";


  }else{
    data = new Date();
    var dia = date.getDay();
    var mes = date.getMonth();
    var ano = date.getYear();
    mes = mes - 1;
   

    var arrayMes = [12];

        arrayMes[0] = "Janeiro";

        arrayMes[1] = "Fevereiro";

        arrayMes[2] = "Março";

        arrayMes[3] = "Abril";

        arrayMes[4] = "Maio";

        arrayMes[5] = "Junho";

        arrayMes[6] = "Julho";

        arrayMes[7] = "Agosto";

        arrayMes[8] = "Setembro";

        arrayMes[9] = "Outubro";

        arrayMes[10] = "Novembro";

        arrayMes[11] = "Dezembro";

   document.write(dia + " " + 'de' + " " + " " + arrayMes[mes] + " " + ano);
  }
}

